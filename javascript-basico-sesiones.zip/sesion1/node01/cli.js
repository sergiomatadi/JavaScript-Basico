
var shell = require("shelljs");
shell.exec("node step1script.js");