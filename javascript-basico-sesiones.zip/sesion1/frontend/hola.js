

 console.log('Hola mundo');