
console.log('Hola mundo en cliente');