
alert("hola");
console.log("hola por la consola")
