/* eslint-disable eol-last *//* eslint-disable linebreak-style */
// instalamos EsLint
// eslint-disable-next-line linebreak-style
// con npm install --save-dev eslint


const b = 'hola';
const c = 'qué tal';

const frase = '! hola ' + b + '! ¡' + c;

console.log(frase);


// lo lanzamos con $ npx eslint --init
// npx eslint src/js/index.js
// npx eslint src/js/index.js