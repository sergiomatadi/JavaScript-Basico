

    let a = 10
    let b = 20
    let c = "hola"

    let misuma = a + b + c
    console.log(misuma)

    const dd = 45
    console.log(dd)

    for(let i = 0; i<10; i++) {
        if(i==5) break
    }

    const f = function(p1, p2, p3) {
        let division = p1 / p3
        return p3 + p1 + p2
    }

    let resultado = f(a, b, c)

    console.log(resultado)